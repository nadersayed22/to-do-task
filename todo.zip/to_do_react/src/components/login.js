import React, { Component ,  setState , useEffect}  from 'react';
import { useHistory } from "react-router-dom";


 const Login = () => {
    const history = useHistory();
useEffect(() => {


    }, [

        ]);
  let state = {
    credentials: {username: '', password: ''}
  }

  let login = event => {
    fetch('http://127.0.0.1:8000/api/login/', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(state.credentials)
    })
    .then( data => data.json())
    .then(
      data => {

        history.push('/Home');

      }
    )
    .catch( error => console.error(error))
  }

  let register = event => {
    fetch('http://127.0.0.1:8000/api/profile/', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(state.credentials)
    })
    .then( data => data.json())
    .then(
      data => {
        console.log(data.token);
      }
    )
    .catch( error => console.error(error))
  }
  let inputChanged = event => {
    const cred = state.credentials;
    debugger;
    cred[event.target.name] = event.target.value;
    setState({credentials: cred});
  }


    return (
      <div>
        <h1>Login user form</h1>

        <label>
          Username:
          <input type="text" name="username"
           value={state.credentials.username}
           onChange={inputChanged}/>
        </label>
        <br/>
        <label>
          Password:
          <input type="password" name="password"
           value={state.credentials.password}
           onChange={inputChanged} />
        </label>
        <br/>
        <button onClick={login}>Login</button>
        <button onClick={register}>Register</button>
      </div>
    );
 }


export default Login;